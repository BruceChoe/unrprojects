#include <iostream>
#include <time.h>
#include "llrbt.h"

using std::endl;
using std::cout;

#define AMNT 10
#define RANDRANGE 100

int main() {
	srand(time(NULL));
	LeftLeaningRedBlackTree<int> llrbt;
	int numToIns = 0; // Number to insert
	int	numToDel = 0; // Number to delete

	for (int i = 0; i < AMNT; i++) {
		numToIns = (std::rand() % RANDRANGE + 1); // Random number range is 1 - 100
		if (i == 3) { // Remove the 4th variable inserted 
			numToDel = numToIns;
		}
		cout << "Inserting Value: " << numToIns << endl;
		llrbt.insert(numToIns);
		llrbt.preorderTraverse();
		cout << endl;
	}

	cout << "Deleting value: " << numToDel << endl;
	llrbt.remove(numToDel);
	llrbt.preorderTraverse();
    
	return 0;
}
