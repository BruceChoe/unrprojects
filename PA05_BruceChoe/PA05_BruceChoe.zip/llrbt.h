#pragma once
#ifndef LEFT_LEANING_RED_BLACK_TREE_
#define LEFT_LEANING_RED_BLACK_TREE_

#include "rbNode.h"
#include <iostream>
#include <memory>
#include <algorithm>
#include <string>

using std::cout;
using std::endl;
using std::string;

string printColor(const bool color);
template<class ItemType>
class LeftLeaningRedBlackTree
{
private:
	rbNode<ItemType>* rootPtr;
protected:
	//------------------------------------------------------------
	// Protected Utility Methods Section:
	//------------------------------------------------------------
	rbNode<ItemType>* leftRotate(rbNode<ItemType>* node);
	rbNode<ItemType>* rightRotate(rbNode<ItemType>* node);
	rbNode<ItemType>* insertRec(rbNode<ItemType>* subtree, rbNode<ItemType>* node);
	rbNode<ItemType>* moveRedLeft(rbNode<ItemType>* node);
	rbNode<ItemType>* moveRedRight(rbNode<ItemType>* node);
	rbNode<ItemType>* findMin(rbNode<ItemType>* node);
	rbNode<ItemType>* deleteMin(rbNode<ItemType>* node);
	rbNode<ItemType>* fixUp(rbNode<ItemType>* node);
	rbNode<ItemType>* deleteRec(rbNode<ItemType>* subtree, const ItemType& entry);
	void switchColors(rbNode<ItemType>* node);

    // Helper methods
	bool isRed(rbNode<ItemType>* node) const;
	int getHeightHelper(rbNode<ItemType>* subTreePtr) const;
	void preorder(rbNode<ItemType>* subTreePtr) const;
	void inorder(rbNode<ItemType>* subTreePtr) const;
	void postorder(rbNode<ItemType>* subTreePtr) const;
public:
	//------------------------------------------------------------
	// Constructor and Destructor Section.
	//------------------------------------------------------------
	LeftLeaningRedBlackTree();

	//------------------------------------------------------------
	// Public Methods Section.
	//------------------------------------------------------------
	int getHeight() const;
	void insert(const ItemType& newEntry);
    void remove(const ItemType& entry);
    void visit(const rbNode<ItemType>* subTreePtr) const;
	//------------------------------------------------------------
	// Public Traversals Section.
	//------------------------------------------------------------
	void preorderTraverse() const;
	void inorderTraverse() const;
	void postorderTraverse() const;
};

template<class ItemType>
LeftLeaningRedBlackTree<ItemType>::LeftLeaningRedBlackTree() : rootPtr(nullptr) {
}

template<class ItemType>
rbNode<ItemType>* LeftLeaningRedBlackTree<ItemType>::deleteRec(rbNode<ItemType>* subtree,
	const ItemType& entry) {
	if (entry < subtree->getItem()) {
		if (subtree->getLeftChildPtr() != nullptr) {
            // If pNode and pNode->pLeft are black, we may need to
            // move pRight to become the left child if a deletion
            // would produce a red node.
			if (!isRed(subtree->getLeftChildPtr()) && !isRed(subtree->getLeftChildPtr()->getLeftChildPtr())) {
				subtree = moveRedLeft(subtree);
			}
			subtree->setLeftChildPtr(deleteRec(subtree->getLeftChildPtr(), entry));
		}
	}
	else {
        // If the left child is red, apply a rotation so we make
        // the right child red.
		if (isRed(subtree->getLeftChildPtr())) {
			subtree = rightRotate(subtree);
		}

        // Special case for deletion of a leaf node.
        // The arrangement logic of LLRBs assures that in this case,
        // pNode cannot have a left child.
		if (entry == subtree->getItem() && subtree->getRightChildPtr() == nullptr) {
			delete subtree;
			return nullptr;
		}

        // If we get here, we need to traverse down the right node.
        // However, if there is no right node, then the target key is
        // not in the tree, so we can break out of the recursion.
		if (subtree->getRightChildPtr() != nullptr) {
			if (!isRed(subtree->getRightChildPtr()) && !isRed(subtree->getRightChildPtr()->getLeftChildPtr())) {
				subtree = moveRedRight(subtree);
			}

            // Deletion of an internal node: We cannot delete this node
            // from the tree, so we have to find the node containing
            // the smallest key value that is larger than the key we're
            // deleting.  This other key will replace the value we're
            // deleting, then we can delete the node that previously
            // held the key/value pair we just moved.
			if (entry == subtree->getItem()) {
				subtree->setItem(findMin(subtree->getRightChildPtr())->getItem());
				subtree->setRightChildPtr(deleteMin(subtree->getRightChildPtr()));
			}
			else {
				subtree->setRightChildPtr(deleteRec(subtree->getRightChildPtr(), entry));
			}
		}
	}

    // Fix right-leaning red nodes and eliminate 4-nodes on the way up.
    // Need to avoid allowing search operations to terminate on 4-nodes,
    // or searching may not locate intended key.
	return fixUp(subtree);
}

template<class ItemType>
rbNode<ItemType>* LeftLeaningRedBlackTree<ItemType>::findMin(rbNode<ItemType>* node) {
	while (node->getLeftChildPtr() != nullptr) {
		node = node->getLeftChildPtr();
	}

	return node;
}

template<class ItemType>
rbNode<ItemType>* LeftLeaningRedBlackTree<ItemType>::deleteMin(rbNode<ItemType>* node) {
    // If this node has no children, we're done.
    // Due to the arrangement of an LLRB tree, the node cannot have a
    // right child.
	if (node->getLeftChildPtr() == nullptr) {
		delete node;
		return nullptr;
	}

    // If these nodes are black, we need to rearrange this subtree to
    // force the left child to be red.
	if (!isRed(node->getLeftChildPtr()) && !isRed(node->getLeftChildPtr()->getLeftChildPtr())) {
		node = moveRedLeft(node);
	}

    // Continue recursing to locate the node to delete.
	node->setLeftChildPtr(deleteMin(node->getLeftChildPtr()));

    // Fix right-leaning red nodes and eliminate 4-nodes on the way up.
    // Need to avoid allowing search operations to terminate on 4-nodes,
    // or searching may not locate intended key.
	return fixUp(node);
}

template<class ItemType>
rbNode<ItemType>* LeftLeaningRedBlackTree<ItemType>::moveRedLeft(rbNode<ItemType>* node) {
    // If both children are black, we turn these three nodes into a 4-node by applying a color flip.
	switchColors(node);

    // But we may end up with a case where pRight has a red child.
    // Apply a pair of rotations and a color flip to make pNode a
    // red node, both of its children become black nodes, and pLeft
    // becomes a 3-node.
	if ((nullptr != node->getRightChildPtr()) && isRed(node->getRightChildPtr()->getLeftChildPtr())) {
		node->setRightChildPtr(rightRotate(node->getRightChildPtr()));
		node = leftRotate(node);
		switchColors(node);
	}

	return node;
}

template<class ItemType>
rbNode<ItemType>* LeftLeaningRedBlackTree<ItemType>::moveRedRight(rbNode<ItemType>* node) {
	switchColors(node);

	if (node->getLeftChildPtr() != nullptr && isRed(node->getLeftChildPtr()->getLeftChildPtr())) {
		node = rightRotate(node);
		switchColors(node);
	}

	return node;
}

template<class ItemType>
rbNode<ItemType>* LeftLeaningRedBlackTree<ItemType>::fixUp(rbNode<ItemType>* node) {
    // Fix right-leaning red nodes.
	if (isRed(node->getRightChildPtr())) {
		node = leftRotate(node);
	}

    // Detect if there is a 4-node that traverses down the left.
    // This is fixed by a right rotation, making both of the red
    // nodes the children of pNode.
	if (isRed(node->getLeftChildPtr()) && isRed(node->getLeftChildPtr()->getLeftChildPtr())) {
		node = rightRotate(node);
	}

    // Split 4-nodes.
	if (isRed(node->getLeftChildPtr()) && isRed(node->getRightChildPtr())) {
		switchColors(node);
	}

	return node;
}

template<class ItemType>
rbNode<ItemType>* LeftLeaningRedBlackTree<ItemType>::insertRec(rbNode<ItemType>* subtree, rbNode<ItemType>* node) {
	if (subtree == nullptr) {
		return node;
	}

	if (node->getItem() < subtree->getItem()) {
		subtree->setLeftChildPtr(insertRec(subtree->getLeftChildPtr(), node));
	}
	else {
		subtree->setRightChildPtr(insertRec(subtree->getRightChildPtr(), node));
	}

	if (isRed(subtree->getRightChildPtr()) && !isRed(subtree->getLeftChildPtr())) {
		subtree = leftRotate(subtree);
	}

	if (isRed(subtree->getLeftChildPtr()) && isRed(subtree->getLeftChildPtr()->getLeftChildPtr())) {
		subtree = rightRotate(subtree);
	}

	if (isRed(subtree->getLeftChildPtr()) && isRed(subtree->getRightChildPtr())) {
		switchColors(subtree);
	}

	return subtree;
}

template<class ItemType>
bool LeftLeaningRedBlackTree<ItemType>::isRed(rbNode<ItemType>* node) const {
    if (node == nullptr || node->getColor() == BLACK) {
        return false;
    }
    return true;
}

template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::switchColors(rbNode<ItemType>* node) {
    node->setColor(!(node->getColor()));
    if (node->getLeftChildPtr() != nullptr) {
        node->getLeftChildPtr()->setColor(!(node->getLeftChildPtr()->getColor()));
    }
    if (node->getRightChildPtr() != nullptr) {
        node->getRightChildPtr()->setColor(!(node->getRightChildPtr()->getColor()));
    }
}

template<class ItemType>
rbNode<ItemType>* LeftLeaningRedBlackTree<ItemType>::leftRotate(rbNode<ItemType>* node) {
	rbNode<ItemType>* temp = node->getRightChildPtr();
	node->setRightChildPtr(temp->getLeftChildPtr());
	temp->setLeftChildPtr(node);
	temp->setColor(node->getColor());
	node->setColor(RED);
	return temp;
}

template<class ItemType>
rbNode<ItemType>* LeftLeaningRedBlackTree<ItemType>::rightRotate(rbNode<ItemType>* node) {
	rbNode<ItemType>* temp = node->getLeftChildPtr();
	node->setLeftChildPtr(temp->getRightChildPtr());
	temp->setRightChildPtr(node);
	temp->setColor(node->getColor());
	node->setColor(RED);
	return temp;
}

template<class ItemType>
int LeftLeaningRedBlackTree<ItemType>::getHeightHelper(rbNode<ItemType>* subTreePtr) const {
    if (subTreePtr == nullptr)
        return -1;
    else 
        1 + std::max(getHeightHelper(subTreePtr->getLeftChildPtr()), getHeightHelper(subTreePtr->getRightChildPtr()));
}

template<class ItemType>
int LeftLeaningRedBlackTree<ItemType>::getHeight() const {
	return getHeightHelper(rootPtr);
}

template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::preorder(rbNode<ItemType>* subTreePtr) const {
	if (subTreePtr != nullptr) {
	    visit(subTreePtr);
	    preorder(subTreePtr->getLeftChildPtr());
	    preorder(subTreePtr->getRightChildPtr());
	} else {
        return;
    }
}

template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::inorder(rbNode<ItemType>* subTreePtr) const {
	if (subTreePtr != nullptr) {
	    inorder(subTreePtr->getLeftChildPtr());
        visit(subTreePtr);
	    inorder(subTreePtr->getRightChildPtr());
	} else {
        return;
    }
}

template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::postorder(rbNode<ItemType>* subTreePtr) const {
	if (subTreePtr == nullptr) {
	    postorder(subTreePtr->getLeftChildPtr());
	    postorder(subTreePtr->getRightChildPtr());
	    visit(subTreePtr);
	} else {
        return;
    }
}

template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::preorderTraverse() const {
	cout << "Traversing preorder: " << endl;
	preorder(rootPtr);
	cout << endl;
}

template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::inorderTraverse() const {
	cout << "Traversing inorder: ";
	inorder(rootPtr);
	cout << endl;
}

template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::postorderTraverse() const {
	cout << "Traversing postorder:: ";
	postorder(rootPtr);
	cout << endl;
}
string printColor(const bool color) {
	if (color) {
		return "B";
	}
	return "R";
}

template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::insert(const ItemType& newItem) {
	rbNode<ItemType>* newNodePtr = new rbNode<ItemType>(newItem);
	rootPtr = insertRec(rootPtr, newNodePtr);
	rootPtr->setColor(BLACK);
}

template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::remove(const ItemType& entry) {
	rootPtr = deleteRec(rootPtr, entry);
}
template<class ItemType>
void LeftLeaningRedBlackTree<ItemType>::visit(const rbNode<ItemType>* subTreePtr) const {
    cout << subTreePtr->getItem() << "(" << printColor(subTreePtr->getColor()) << ") ";
}
#endif
