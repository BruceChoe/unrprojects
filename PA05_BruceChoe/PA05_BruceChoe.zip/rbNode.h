#pragma once
#ifndef RED_BLACK_NODE_
#define RED_BLACK_NODE_

#define BLACK true
#define RED false

template<class ItemType>
class rbNode {
private:
	ItemType item; // Data portion
    rbNode<ItemType>* parentPtr; // Pointer to parent/root
	rbNode<ItemType>* rightChildPtr; // Pointer to right child
	rbNode<ItemType>* leftChildPtr; // Pointer to left child
	bool color; // track red/black
public:
    // Constructors
	rbNode(const ItemType& anItem);

    // Accessors 
	ItemType getItem() const;
	rbNode<ItemType>* getParentPtr() const;
	rbNode<ItemType>* getRightChildPtr() const;
	rbNode<ItemType>* getLeftChildPtr() const;
	bool getColor() const;

    // Mutators
	void setItem(const ItemType& anItem);
	void setParentPtr(rbNode<ItemType>* parentPtr);
	void setRightChildPtr(rbNode<ItemType>* rightPtr);
	void setLeftChildPtr(rbNode<ItemType>* leftPtr);
	void setColor(const bool newColor);
};

// Constructors
template<class ItemType>
rbNode<ItemType>::rbNode(const ItemType& anItem) : item(anItem), parentPtr(nullptr), rightChildPtr(nullptr), leftChildPtr(nullptr), color(RED) {
}
 
// Accessors
template<class ItemType>
ItemType rbNode<ItemType>::getItem() const {
	return item;
}

template<class ItemType>
rbNode<ItemType>* rbNode<ItemType>::getParentPtr() const {
	return parentPtr;
}

template<class ItemType>
rbNode<ItemType>* rbNode<ItemType>::getRightChildPtr() const {
	return rightChildPtr;
}

template<class ItemType>
rbNode<ItemType>* rbNode<ItemType>::getLeftChildPtr() const {
	return leftChildPtr;
}

template<class ItemType>
bool rbNode<ItemType>::getColor() const {
	return color;
}

// Mutators
template<class ItemType>
void rbNode<ItemType>::setItem(const ItemType& newItem) {
	item = newItem;
}

template<class ItemType>
void rbNode<ItemType>::setParentPtr(rbNode<ItemType>* parent) {
	parentPtr = parent;
}

template<class ItemType>
void rbNode<ItemType>::setRightChildPtr(rbNode<ItemType>* rightPtr) {
	rightChildPtr = rightPtr;
}

template<class ItemType>
void rbNode<ItemType>::setLeftChildPtr(rbNode<ItemType>* leftPtr) {
	leftChildPtr = leftPtr;
}

template<class ItemType>
void rbNode<ItemType>::setColor(const bool newColor) {
	color = newColor;
}

#endif
